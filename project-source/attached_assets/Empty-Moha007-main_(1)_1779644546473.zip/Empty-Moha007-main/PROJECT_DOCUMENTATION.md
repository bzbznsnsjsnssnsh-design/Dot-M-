# 📚 وثيقة شاملة لمشروع Empty-Space-j-j

## 📖 جدول المحتويات
- [نظرة عامة على المشروع](#نظرة-عامة-على-المشروع)
- [البنية الأساسية](#البنية-الأساسية)
- [ملفات الجذر](#ملفات-الجذر)
- [المكتبات المشتركة](#المكتبات-المشتركة)
- [التطبيقات](#التطبيقات)
- [سير العمل](#سير-العمل-الكامل)
- [الأوامر والتشغيل](#الأوامر-والتشغيل)

---

## 🎯 نظرة عامة على المشروع

### ما هو المشروع؟
**Empty-Space-j-j** هو تطبيق متكامل لترجمة فيديوهات YouTube تلقائياً مع الحفاظ على التزامن الصوتي. يقوم بـ:

1. **تحميل فيديو من YouTube** 📥
2. **استخراج الصوت الأصلي** 🎵
3. **تحويل الصوت إلى نص (ASR)** 📝
4. **ترجمة النص إلى العربية** 🌍
5. **تحويل النص المترجم إلى صوت عربي (TTS)** 🔊
6. **خدمة الملفات الصوتية المعالجة** 📤

### البيانات التقنية
```
Language Composition:
- TypeScript: 95.5% ⭐
- CSS: 2.1%
- Other: 2.4%

Repository:
- ID: 1235788194
- Owner: bzbznsnsjsnssnsh-design
- Created: قبل 3 ساعات
- Size: 373 KB
- Visibility: Public
```

### التقنيات المستخدمة
| الفئة | التقنية |
|------|---------|
| **Runtime** | Node.js 24 + Python 3.11 |
| **Language** | TypeScript 5.9 |
| **Package Manager** | pnpm + pip |
| **API Framework** | Express 5 |
| **Database** | PostgreSQL + Drizzle ORM |
| **Validation** | Zod v4 |
| **Build Tool** | esbuild (ESM) |
| **TTS Engine** | edge-tts (Microsoft) |
| **ASR Engine** | faster-whisper (faster implementation of OpenAI Whisper) |
| **Video Download** | yt-dlp |
| **API Documentation** | OpenAPI 3.1.0 + Orval |
| **Code Generation** | Orval (from OpenAPI spec) |

---

## 🏗️ البنية الأساسية

### هيكل المشروع الكامل
```
Empty-Space-j-j/
│
├── 📄 ملفات التكوين الرئيسية
│   ├── .gitignore                 # تجاهل الملفات عند Git
│   ├── .npmrc                     # إعدادات npm
│   ├── .replit                    # إعدادات منصة Replit
│   ├── .replitignore              # تجاهل أثناء النشر
│   ├── package.json               # تبعيات الجذر والـ scripts
│   ├── pnpm-workspace.yaml        # إعدادات Monorepo
│   ├── pyproject.toml             # تبعيات Python
│   ├── main.py                    # نقطة دخول Python
│   ├── replit.md                  # توثيق المشروع
│   ├── tsconfig.json              # إعدادات TypeScript الجذر
│   └── tsconfig.base.json         # إعدادات TypeScript الأساسية
│
├── 📦 lib/ (المكتبات المشتركة)
│   ├── db/                        # قاعدة البيانات
│   │   ├── package.json
│   │   ├── drizzle.config.ts
│   │   ├── tsconfig.json
│   │   └── src/
│   │       ├── index.ts           # إعادة تصدير DB و Pool
│   │       └── schema/
│   │           └── index.ts       # تعريفات الجداول (فارغ حالياً)
│   │
│   ├── api-zod/                   # Zod Validation Schemas
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   └── src/
│   │       ├── index.ts           # تصدير الـ Schemas
│   │       └── generated/
│   │           ├── api.ts         # Schemas المُنتجة من OpenAPI
│   │           └── types/         # أنواع TypeScript
│   │
│   ├── api-spec/                  # مواصفات API
│   │   ├── package.json
│   │   ├── openapi.yaml           # مواصفة OpenAPI الكاملة
│   │   └── orval.config.ts        # إعدادات Code Generation
│   │
│   └── api-client-react/          # React Query Client
│       ├── package.json
│       ├── tsconfig.json
│       └── src/
│           └── index.ts           # (قيد التطوير)
│
├── 🎯 artifacts/ (التطبيقات الجاهزة)
│   ├── api-server/                # الخادم الرئيسي
│   │   ├── package.json
│   │   ├── tsconfig.json
│   │   ├── build.mjs              # سكريبت البناء (esbuild)
│   │   └── src/
│   │       ├── index.ts           # نقطة البداية
│   │       ├── app.ts             # تطبيق Express
│   │       ├── whisper_local.py   # ASR Script (Python)
│   │       ├── lib/
│   │       │   ├── logger.ts      # نظام السجلات
│   │       │   └── .gitkeep
│   │       ├── middlewares/       # (فارغ)
│   │       └── routes/
│   │           ├── index.ts       # تجميع Routes
│   │           ├── health.ts      # Health Check
│   │           └── translate/     # منطق الترجمة
│   │               ├── index.ts   # Main Router
│   │               ├── jobs.ts    # إدارة المهام
│   │               ├── processor.ts # معالجة الفيديو (الملف الأساسي)
│   │               ├── cookies.ts  # إدارة كوكيز YouTube
│   │               └── edge-tts.ts # واجهة TTS
│   │
│   ├── mockup-sandbox/            # (قيد التطوير)
│   └── video-translator/          # (قيد التطوير)
│
└── 🔧 scripts/ (أدوات التطوير)
    ├── package.json
    ├── tsconfig.json
    ├── post-merge.sh              # Git Hook
    └── src/
        └── hello.ts               # سكريبت تجريبي
```

---

## 📄 ملفات الجذر

### 1. `.gitignore` (تجاهل الملفات)
**الغرض**: تحديد الملفات والمجلدات التي يتجاهلها Git

```
تجاهل المجلدات:
- dist/                           # الـ Compiled Output
- node_modules/                   # التبعيات
- .expo/                          # Expo Build Cache
- .local/, .cache/                # Replit Cache

تجاهل الملفات:
- *.log                           # ملفات السجلات
- .DS_Store                       # macOS Files
- .vscode/*                       # VSCode (مع استثناءات)
- *.tsbuildinfo                   # TypeScript Build Info
```

### 2. `.npmrc` (إعدادات npm)
```
auto-install-peers=false          # ❌ لا تثبت peer dependencies
strict-peer-dependencies=false    # ❌ لا تفرض قيود peer dependencies
```

**السبب**: لتجنب التضاربات عند استخدام pnpm workspace

### 3. `.replit` (إعدادات Replit) 🌐
```
modules = ["nodejs-24", "python-3.11"]
  ↓
يوفر بيئات تطوير Node.js و Python

deployment:
  - router = "application"        # للتطبيقات
  - deploymentTarget = "autoscale" # تحسين تلقائي
  
[deployment.postBuild]:
  - أمر: pnpm store prune         # تنظيف التخزين
  - env: CI=true                  # Continuous Integration
  
[workflows]:
  - runButton = "Project"         # زر التشغيل
  
[agent]:
  - stack = "PNPM_WORKSPACE"      # نوع المشروع
  - expertMode = true             # وضع متقدم
  
[postMerge]:
  - path = "scripts/post-merge.sh" # تشغيل تلقائي بعد merge
  
[ports]:
  تعيين المنافذ المحلية للخارجية:
  - 5000 → 5000
  - 8080 → 8080
  - 8081 → 80   (Web)
  - 8082 → 4200 (Angular)
  - 8083 → 3000 (React)
  - ...
  
[nix]:
  - channel = "stable-25_05"      # نسخة نظام الحزم
```

### 4. `package.json` (الجذر)
```json
{
  "name": "workspace",
  "version": "0.0.0",
  "private": true,                    # لا نشر على npm
  
  "scripts": {
    "build": "pnpm run typecheck && pnpm -r --if-present run build",
    "typecheck": "فحص أنواع TypeScript الكامل",
    "typecheck:libs": "فحص lib فقط"
  },
  
  "devDependencies": {
    "typescript": "~5.9.2",          # لا تجديد إصدارات رئيسية
    "prettier": "^3.8.1"             # تنسيق الكود
  }
}
```

### 5. `pnpm-workspace.yaml` (Monorepo Configuration)

#### أمان Supply Chain 🔒
```yaml
minimumReleaseAge: 1440              # 24 ساعة
# ↓
# لا تثبت حزم npm جديدة إلا بعد يوم من نشرها
# (دفاع ضد الهجمات على سلسلة التوريد)

minimumReleaseAgeExclude:
  - '@replit/*'                      # استثناء الحزم الموثوقة
  - stripe-replit-sync
```

#### Packages (الحزم المكونة للـ Monorepo)
```yaml
packages:
  - artifacts/*                      # جميع التطبيقات
  - lib/*                            # جميع المكتبات
  - lib/integrations/*               # تكاملات محددة
  - scripts                          # أدوات التطوير
```

#### Catalog (إصدارات موحدة)
```yaml
catalog:
  '@types/node': ^25.3.3
  typescript: ~5.9.2
  zod: ^3.25.76
  drizzle-orm: ^0.45.2
  react: 19.1.0                      # ثابت للـ Expo
  vite: ^7.3.2
  tailwindcss: ^4.1.14
  framer-motion: ^12.23.24
  lucide-react: ^0.545.0
  # ... و20+ حزمة أخرى
```

**الفائدة**: تجنب تضارب الإصدارات

#### Overrides (تحسينات المنصة)
```yaml
overrides:
  # Replit = Linux x64 فقط
  "esbuild>@esbuild/darwin-arm64": "-"      # ❌ macOS Intel
  "esbuild>@esbuild/darwin-x64": "-"        # ❌ macOS Silicon
  "esbuild>@esbuild/win32-*": "-"           # ❌ Windows
  "esbuild>@esbuild/linux-arm64": "-"       # ❌ ARM
  # بقية الـ platforms
```

### 6. `pyproject.toml` (Python Dependencies)
```toml
[project]
name = "repl-nix-workspace"
requires-python = ">=3.11"

dependencies = [
  "edge-tts>=7.2.8",               # Microsoft Text-to-Speech
  "faster-whisper>=1.2.1"          # OpenAI Whisper (محسّن)
]
```

### 7. `main.py` (Python Entry Point)
```python
def main():
    print("Hello from repl-nix-workspace!")

if __name__ == "__main__":
    main()
```

### 8. `replit.md` (Project Documentation)
```markdown
# Workspace

## Overview
- Monorepo مع pnpm workspaces
- Each package manages its own dependencies

## Stack
- Node.js 24
- TypeScript 5.9
- Express 5 (API)
- PostgreSQL + Drizzle ORM (Database)
- Zod v4 (Validation)
- Orval (API Code Generation)
- esbuild (Build)

## Key Commands
- pnpm run typecheck
- pnpm run build
- pnpm --filter @workspace/api-server run dev
- pnpm --filter @workspace/db run push
```

### 9. `tsconfig.json` (TypeScript - الجذر)
```json
{
  "extends": "./tsconfig.base.json",
  "compileOnSave": false,
  "files": [],
  
  "references": [                    # Project References
    { "path": "./lib/db" },
    { "path": "./lib/api-client-react" },
    { "path": "./lib/api-zod" }
  ]
}
```

**الغرض**: Monorepo Support + Incremental Compilation

### 10. `tsconfig.base.json` (TypeScript - الأساسي)
```json
{
  "compilerOptions": {
    "target": "es2022",              # JavaScript Features
    "module": "esnext",              # ESM Format
    "lib": ["es2022"],               # Built-in Types
    
    "strict": true,                  # Strict Mode
    "noImplicitAny": true,           # كل شيء يحتاج type
    "strictNullChecks": true,        # null/undefined checks
    "noImplicitThis": true,
    "strictFunctionTypes": false,    # أقل صرامة للـ functions
    "strictBindCallApply": true,
    "strictPropertyInitialization": true,
    
    "noUnusedLocals": false,         # تنبيهات فقط
    "noEmitOnError": true,           # لا تُخرج إذا حدث خطأ
    "noFallthroughCasesInSwitch": true,
    "useUnknownInCatchVariables": true,
    
    "isolatedModules": true,         # كل ملف مستقل
    "skipLibCheck": true,            # لا تفحص .d.ts
    "moduleResolution": "bundler",   # Resolution Strategy
    "customConditions": ["workspace"] # للـ workspace exports
  }
}
```

---

## 📦 المكتبات المشتركة (lib/)

### 1. `lib/db/` (قاعدة البيانات)

#### البنية
```
lib/db/
├── package.json         # Drizzle ORM + PostgreSQL Driver
├── drizzle.config.ts   # إعدادات الترحيل
├── tsconfig.json       # TypeScript Config
└── src/
    ├── index.ts        # تصدير Pool و DB Instance
    └── schema/
        └── index.ts    # تعريفات الجداول (مشروع)
```

#### `package.json`
```json
{
  "name": "@workspace/db",
  "exports": {
    ".": "./src/index.ts",
    "./schema": "./src/schema/index.ts"  # Dual exports
  },
  
  "scripts": {
    "push": "drizzle-kit push",          # Apply migrations
    "push-force": "drizzle-kit push --force"
  },
  
  "dependencies": {
    "drizzle-orm": "^0.45.2",            # ORM
    "drizzle-zod": "^0.8.3",             # Schema ↔ Zod
    "pg": "^8.20.0",                     # PostgreSQL Driver
    "zod": "^3.25.76"                    # Validation
  }
}
```

#### `drizzle.config.ts`
```typescript
import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./src/schema/index.ts",       # Schema Path
  dialect: "postgresql",                  # Database Type
  dbCredentials: {
    url: process.env.DATABASE_URL         # من البيئة
  }
});
```

#### `src/index.ts`
```typescript
import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

// التحقق من وجود DATABASE_URL
if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set...");
}

// إنشاء Connection Pool
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

// إنشاء Drizzle Instance
export const db = drizzle(pool, { schema });

// تصدير جميع الـ Schemas
export * from "./schema";
```

#### `src/schema/index.ts` (قالب)
```typescript
// قالب للإضافة إليه:
// 
// export const postsTable = pgTable("posts", {
//   id: serial("id").primaryKey(),
//   title: text("title").notNull(),
// });
//
// export const insertPostSchema = createInsertSchema(postsTable).omit({ id: true });
// export type InsertPost = z.infer<typeof insertPostSchema>;
// export type Post = typeof postsTable.$inferSelect;
```

---

### 2. `lib/api-spec/` (OpenAPI Specification)

#### البنية
```
lib/api-spec/
├── package.json        # Orval (Code Generator)
├── openapi.yaml        # مواصفات API الكاملة
└── orval.config.ts    # إعدادات Generation
```

#### `openapi.yaml` (مواصفات API)

**المعلومات الأساسية:**
```yaml
openapi: 3.1.0
info:
  title: Api                        # اسم API
  version: 0.1.0
  description: API specification

servers:
  - url: /api
    description: Base API path
```

**الـ Tags (التصنيفات):**
```yaml
tags:
  - name: health
    description: Health check operations
  
  - name: translate
    description: Video translation operations
```

**الـ Endpoints:**

1️⃣ **Health Check**
```yaml
/healthz:
  get:
    operationId: healthCheck
    tags: [health]
    summary: Health check
    responses:
      "200":
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/HealthStatus"
```

2️⃣ **Process Video**
```yaml
/translate/process:
  post:
    operationId: processVideo
    tags: [translate]
    summary: Process video segment
    requestBody:
      content:
        application/json:
          schema:
            $ref: "#/components/schemas/ProcessVideoRequest"
    responses:
      "200":
        schema: ProcessVideoResponse
      "400":
        schema: ErrorResponse
```

3️⃣ **Get Job Status**
```yaml
/translate/status/{jobId}:
  get:
    operationId: getJobStatus
    parameters:
      - name: jobId (path parameter)
    responses:
      "200": JobStatusResponse
      "404": ErrorResponse
```

4️⃣ **Get TTS Models**
```yaml
/translate/models:
  get:
    operationId: getTtsModels
    responses:
      "200": TtsModelsResponse
```

5️⃣ **Cookies Management**
```yaml
/translate/cookies/status:
  get:
    operationId: getCookiesStatus
    responses: "200": CookiesStatusResponse

/translate/cookies:
  post:
    operationId: saveCookies
    responses: "200": SuccessResponse
  
  delete:
    operationId: deleteCookies
    responses: "200": SuccessResponse
```

**المخططات (Schemas):**
```yaml
components:
  schemas:
    HealthStatus:
      type: object
      properties:
        status: string
    
    ProcessVideoRequest:
      type: object
      properties:
        videoUrl: string              # YouTube URL
        startTime: number             # بالثواني
        voice: string                 # TTS Voice ID
        translationEngine:
          enum: [openai, google, pollinations]
    
    JobStatusResponse:
      type: object
      properties:
        jobId: string
        status: enum [pending, processing, completed, failed]
        progress: string              # الرسالة (عربي)
        audioUrl: string (nullable)
        transcript: string            # النص الأصلي
        translation: string           # النص المترجم
        error: string
        startTime: number
        suggestedRate: number
        audioDurationSec: number
    
    TtsVoice:
      properties:
        id: string                    # ar-SA-HamedNeural
        name: string                  # 🇸🇦 حامد - السعودية
        lang: string                  # ar-SA
    
    # ... وغيرها
```

#### `orval.config.ts` (Code Generation Config)
```typescript
import { defineConfig } from "orval";

export default defineConfig({
  // Generator 1: React Query Client
  "api-client-react": {
    input: {
      target: "./openapi.yaml"
    },
    output: {
      workspace: "lib/api-client-react/src",
      target: "generated",
      client: "react-query",            // React Hook
      mode: "split",                    // Multiple files
      baseUrl: "/api"
    }
  },
  
  // Generator 2: Zod Schemas
  zod: {
    input: {
      target: "./openapi.yaml"
    },
    output: {
      workspace: "lib/api-zod/src",
      target: "generated/api.ts",
      client: "zod",                    // Zod Validation
      mode: "single"                    // Single file
    }
  }
});
```

**الغرض**: توليد الأكواد تلقائياً من OpenAPI!

---

### 3. `lib/api-zod/` (Validation Schemas)

#### البنية
```
lib/api-zod/
├── package.json
├── tsconfig.json
└── src/
    ├── index.ts                    # تصدير الـ Schemas
    └── generated/
        ├── api.ts                  # Zod Schemas (auto-generated)
        └── types/                  # TypeScript Types
            ├── healthStatus.ts
            ├── jobStatusResponse.ts
            ├── ttsVoice.ts
            └── ... (أنواع أخرى)
```

#### `package.json`
```json
{
  "name": "@workspace/api-zod",
  "dependencies": {
    "zod": "^3.25.76"                # Validation Library
  }
}
```

#### `src/index.ts` (التصدير)
```typescript
export * from "./generated/api";
export * from "./generated/types/healthStatus";
export * from "./generated/types/jobStatusResponse";
export * from "./generated/types/ttsModelsResponse";
export * from "./generated/types/ttsVoice";
export * from "./generated/types/cookiesStatusResponse";
export * from "./generated/types/errorResponse";
export * from "./generated/types/saveCookiesRequest";
export * from "./generated/types/successResponse";
```

#### `src/generated/api.ts` (Auto-Generated Schemas)
```typescript
/**
 * Generated by orval v8.5.3 🍺
 * Do not edit manually.
 */

// Health Check
export const HealthCheckResponse = zod.object({
  status: zod.string()
});

// Process Video Request
export const ProcessVideoBody = zod.object({
  videoUrl: zod.string(),
  startTime: zod.number(),
  voice: zod.string(),
  translationEngine: zod
    .enum(["openai", "google", "pollinations"])
    .optional(),
  forceAudioExtraction: zod.boolean().optional()
});

export const ProcessVideoResponse = zod.object({
  jobId: zod.string(),
  status: zod.string(),
  message: zod.string()
});

// Get Job Status
export const GetJobStatusParams = zod.object({
  jobId: zod.coerce.string()
});

export const GetJobStatusResponse = zod.object({
  jobId: zod.string(),
  status: zod.enum(["pending", "processing", "completed", "failed"]),
  progress: zod.string(),
  audioUrl: zod.string().nullish(),
  transcript: zod.string().nullish(),
  translation: zod.string().nullish(),
  error: zod.string().nullish(),
  startTime: zod.number().nullish(),
  suggestedRate: zod.number().nullish()
});

// TTS Models
export const GetTtsModelsResponse = zod.object({
  voices: zod.array(
    zod.object({
      id: zod.string(),
      name: zod.string(),
      lang: zod.string()
    })
  )
});

// Cookies
export const GetCookiesStatusResponse = zod.object({
  hasCookies: zod.boolean()
});

export const SaveCookiesBody = zod.object({
  cookies: zod.string()
});

export const SaveCookiesResponse = zod.object({
  success: zod.boolean(),
  message: zod.string().optional()
});

export const DeleteCookiesResponse = zod.object({
  success: zod.boolean(),
  message: zod.string().optional()
});
```

---

### 4. `lib/api-client-react/` (React Query Client)

#### البنية
```
lib/api-client-react/
├── package.json
├── tsconfig.json
└── src/
    ├── index.ts                    # تصدير الـ Hooks
    └── generated/
        ├── api.ts (auto-generated)
        └── custom-fetch.ts         # Custom Fetch Config
```

#### `package.json`
```json
{
  "name": "@workspace/api-client-react",
  "dependencies": {
    "@tanstack/react-query": "^5.90.21"
  },
  "peerDependencies": {
    "react": ">=18"
  }
}
```

**الغرض**: React Hooks لـ API Calls

---

## 🎯 التطبيقات (artifacts/)

### `artifacts/api-server/` (الخادم الرئيسي)

#### البنية
```
artifacts/api-server/
├── package.json
├── tsconfig.json
├── build.mjs               # 🔨 Build Script
├── src/
│   ├── index.ts            # 🚀 Entry Point
│   ├── app.ts              # Express App
│   ├── whisper_local.py    # 🐍 ASR (Python)
│   ├── lib/
│   │   └── logger.ts       # 📝 Logging
│   └── routes/
│       ├── index.ts
│       ├── health.ts
│       └── translate/      # 🎬 Main Logic
│           ├── index.ts
│           ├── jobs.ts
│           ├── processor.ts
│           ├── cookies.ts
│           └── edge-tts.ts
└── .replit-artifact/
```

#### `package.json`
```json
{
  "name": "@workspace/api-server",
  "type": "module",
  
  "scripts": {
    "dev": "export NODE_ENV=development && pnpm run build && pnpm run start",
    "build": "node ./build.mjs",
    "start": "node --enable-source-maps ./dist/index.mjs",
    "typecheck": "tsc -p tsconfig.json --noEmit"
  },
  
  "dependencies": {
    "@workspace/api-zod": "workspace:*",
    "@workspace/db": "workspace:*",
    "express": "^5",
    "openai": "^4.98.0",           # OpenAI API
    "pino": "^9",                  # Logging
    "pino-http": "^10",
    "cors": "^2",
    "cookie-parser": "^1.4.7"
  },
  
  "devDependencies": {
    "@types/express": "^5.0.6",
    "esbuild": "^0.27.3",
    "esbuild-plugin-pino": "^2.3.3"  # Pino Support in esbuild
  }
}
```

#### `build.mjs` (Build Script - 🔨)
```javascript
import { build as esbuild } from "esbuild";

await esbuild({
  entryPoints: ["src/index.ts"],
  platform: "node",                  // 🖥️ Node.js Target
  bundle: true,                      // 📦 Bundle All Files
  format: "esm",                     // 📄 ESM Format (.mjs)
  outdir: "dist",
  outExtension: { ".js": ".mjs" },
  
  // لا تُجمع هذه (موجودة في النظام):
  external: [
    "*.node",                        # Native modules
    "sharp",                         # Image processing
    "canvas",                        # Canvas drawing
    "bcrypt",                        # Password hashing
    "@prisma/client",                # Prisma ORM
    "@google-cloud/*",
    "@aws-sdk/*",
    "playwright",
    "puppeteer",
    "electron",
    # ... و100 حزمة أخرى
  ],
  
  sourcemap: "linked",               # 🐛 Debugging
  
  plugins: [
    esbuildPluginPino()              # Pino Logger Support
  ],
  
  banner: {
    js: `                           # ✨ ESM Polyfill
      import { createRequire } from 'node:module';
      globalThis.require = createRequire(import.meta.url);
      globalThis.__filename = ...
      globalThis.__dirname = ...
    `
  }
});
```

#### `src/index.ts` (Entry Point)
```typescript
import app from "./app";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }
  logger.info({ port }, "Server listening");
});
```

#### `src/app.ts` (Express Application)
```typescript
import express from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app = express();

// 🔍 Middleware: HTTP Logging
app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0]
        };
      }
    }
  })
);

// 🌐 Middleware: CORS
app.use(cors());

// 📄 Middleware: JSON Parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 🛣️ Routes
app.use("/api", router);

export default app;
```

#### `src/lib/logger.ts` (Logging Configuration)
```typescript
import pino from "pino";

const isProduction = process.env.NODE_ENV === "production";

export const logger = pino({
  level: process.env.LOG_LEVEL ?? "info",
  
  // 🔐 إخفاء البيانات الحساسة:
  redact: [
    "req.headers.authorization",
    "req.headers.cookie",
    "res.headers['set-cookie']"
  ],
  
  // 🌈 في التطوير: ألوان
  // 📝 في الإنتاج: JSON
  ...(isProduction ? {} : {
    transport: {
      target: "pino-pretty",
      options: { colorize: true }
    }
  })
});
```

#### `src/routes/index.ts` (Route Aggregator)
```typescript
import { Router } from "express";
import healthRouter from "./health";
import translateRouter from "./translate/index.js";

const router = Router();

router.use(healthRouter);        # GET /api/healthz
router.use(translateRouter);     # /api/translate/*

export default router;
```

#### `src/routes/health.ts` (Health Check)
```typescript
import { Router } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";

const router = Router();

router.get("/healthz", (_req, res) => {
  // ✅ Validate with Zod
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

export default router;
```

---

#### `src/routes/translate/` (Main Translation Logic)

**`index.ts` (Main Router):**
```typescript
import { Router } from "express";
import { createReadStream, existsSync } from "fs";
import { ProcessVideoBody, GetJobStatusParams } from "@workspace/api-zod";
import { createJob, getJob } from "./jobs.js";
import { processVideoSegment } from "./processor.js";
import { saveCookies, deleteCookies, hasCookies } from "./cookies.js";

const router = Router();

// 🎙️ GET /api/translate/models
// Return: { voices: [...] }
router.get("/translate/models", (_req, res) => {
  res.json({ voices: TTS_VOICES });
});

// 🎬 GET /api/translate/info?url=...
// Return: { title: "..." }
router.get("/translate/info", async (req, res) => {
  const { url } = req.query;
  if (!url || typeof url !== "string") {
    res.status(400).json({ error: "url required" });
    return;
  }
  const info = await getVideoInfo(url);
  res.json(info);
});

// 📋 GET /api/translate/cookies/status
// Return: { hasCookies: true/false }
router.get("/translate/cookies/status", async (_req, res) => {
  const has = await hasCookies();
  res.json({ hasCookies: has });
});

// 💾 POST /api/translate/cookies
// Body: { cookies: "..." }
router.post("/translate/cookies", async (req, res) => {
  const { cookies } = req.body;
  if (!cookies || typeof cookies !== "string" || cookies.length < 10) {
    res.status(400).json({ error: "يرجى تقديم محتوى الكوكيز" });
    return;
  }
  try {
    await saveCookies(cookies.trim());
    res.json({ success: true, message: "تم حفظ الكوكيز بنجاح ✅" });
  } catch (err) {
    res.status(400).json({ error: err?.message });
  }
});

// 🗑️ DELETE /api/translate/cookies
router.delete("/translate/cookies", async (_req, res) => {
  await deleteCookies();
  res.json({ success: true, message: "تم حذف الكوكيز" });
});

// 🚀 POST /api/translate/process
// Body: { videoUrl, startTime, voice, translationEngine }
router.post("/translate/process", async (req, res) => {
  const parsed = ProcessVideoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "validation_error", message: parsed.error.message });
    return;
  }

  const { videoUrl, startTime, voice, translationEngine } = parsed.data;
  const job = createJob(startTime);

  // 🔄 Process in background (no await)
  processVideoSegment({
    jobId: job.jobId,
    videoUrl,
    startTime,
    voice,
    translationEngine: translationEngine as any,
    forceAudioExtraction: true
  }).catch(() => {});

  res.json({ jobId: job.jobId, status: job.status, message: "بدأت المعالجة" });
});

// 📊 GET /api/translate/status/:jobId
// Return: { jobId, status, progress, transcript, translation, sentences, ... }
router.get("/translate/status/:jobId", (req, res) => {
  const parsed = GetJobStatusParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: "validation_error" });
    return;
  }

  const job = getJob(parsed.data.jobId);
  if (!job) {
    res.status(404).json({ error: "not_found", message: "المهمة غير موجودة" });
    return;
  }

  res.json({
    jobId: job.jobId,
    status: job.status,
    progress: job.progress,
    audioUrl: null,                    # Per-sentence mode (no single file)
    transcript: job.transcript,
    translation: job.translation,
    error: job.error,
    startTime: job.startTime,
    suggestedRate: job.suggestedRate,
    audioDurationSec: job.audioDurationSec,
    sentences: job.sentences
  });
});

// 🔊 GET /api/translate/sentence-audio/:jobId/:idx
// Return: audio/mpeg file
router.get("/translate/sentence-audio/:jobId/:idx", (req, res) => {
  const { jobId, idx } = req.params;
  const sentenceIdx = parseInt(idx, 10);
  
  if (!jobId || isNaN(sentenceIdx) || sentenceIdx < 0) {
    res.status(400).json({ error: "invalid_params" });
    return;
  }

  const audioPath = getSentenceAudioPath(jobId, sentenceIdx);
  if (!audioPath || !existsSync(audioPath)) {
    res.status(404).json({ error: "not_found" });
    return;
  }

  res.setHeader("Content-Type", "audio/mpeg");
  res.setHeader("Cache-Control", "public, max-age=3600");
  createReadStream(audioPath).pipe(res);
});

export default router;
```

**`jobs.ts` (Job Management):**
```typescript
import { randomUUID } from "crypto";

// Status Types
export type JobStatus = "pending" | "processing" | "completed" | "failed";
export type SentenceStatus = "pending" | "translating" | "tts" | "completed" | "failed";

// Interfaces
export interface StoredSentence {
  videoStart: number
  videoEnd: number
  arabicText: string
  audioStart: number
  audioEnd: number
  audioUrl?: string
  audioDuration?: number
  sentenceStatus?: SentenceStatus
}

export interface Job {
  jobId: string
  status: JobStatus
  progress: string              # Current status message (Arabic)
  audioPath: string | null
  transcript: string | null     # Original text
  translation: string | null    # Translated text
  error: string | null
  startTime: number | null      # Video start time
  createdAt: number
  suggestedRate: number | null
  audioDurationSec: number | null
  sentences: StoredSentence[] | null  # Per-sentence data
}

// In-memory storage
const jobs = new Map<string, Job>();

// Cleanup config
const MAX_JOBS = 100              # Keep only 100 recent jobs
const JOB_TTL_MS = 60 * 60 * 1000 # 1 hour TTL

function cleanOldJobs() {
  // Delete oldest jobs if > MAX_JOBS
  // Delete jobs older than 1 hour
}

export function createJob(startTime: number): Job {
  cleanOldJobs();
  const jobId = randomUUID();
  const job: Job = {
    jobId,
    status: "pending",
    progress: "في الانتظار...",
    audioPath: null,
    transcript: null,
    translation: null,
    error: null,
    startTime,
    createdAt: Date.now(),
    suggestedRate: null,
    audioDurationSec: null,
    sentences: null
  };
  jobs.set(jobId, job);
  return job;
}

export function getJob(jobId: string): Job | undefined {
  return jobs.get(jobId);
}

export function updateJob(jobId: string, updates: Partial<Job>) {
  const job = jobs.get(jobId);
  if (job) {
    Object.assign(job, updates);
    jobs.set(jobId, job);
  }
}
```

**`cookies.ts` (YouTube Cookies Management):**
```typescript
import { writeFile, unlink, access } from "fs/promises";
import { join } from "path";
import { tmpdir } from "os";
import { constants } from "fs";

const COOKIES_FILE = join(tmpdir(), "yt-cookies.txt");

export function getCookiesPath(): string {
  return COOKIES_FILE;
}

export async function hasCookies(): Promise<boolean> {
  try {
    await access(COOKIES_FILE, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

export async function saveCookies(content: string): Promise<void> {
  // تحقق من أن الملف يحتوي على كوكيز YouTube
  const lines = content.split("\n").filter(Boolean);
  const hasCookieLines = lines.some(
    l => l.includes(".youtube.com") || l.includes("google.com")
  );

  if (!hasCookieLines) {
    throw new Error("ملف الكوكيز لا يحتوي على كوكيز يوتيوب صحيحة");
  }

  await writeFile(COOKIES_FILE, content, "utf-8");
}

export async function deleteCookies(): Promise<void> {
  try {
    await unlink(COOKIES_FILE);
  } catch { /* ignore */ }
}
```

**`edge-tts.ts` (Text-to-Speech):**
```typescript
import { execFile } from "child_process";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

export async function synthesizeEdgeTTS(
  text: string,
  voice: string,
  speed: number,           # 1.0 = normal speed
  outputPath: string
): Promise<void> {
  // Speed percentage: 1.5 = +50%, 0.8 = -20%
  const ratePercent = Math.round((speed - 1.0) * 100);
  const rateStr = ratePercent >= 0 ? `+${ratePercent}%` : `${ratePercent}%`;

  await execFileAsync("python3", [
    "-m", "edge_tts",
    "--voice", voice,
    "--rate", rateStr,
    "--text", text,
    "--write-media", outputPath
  ], {
    timeout: 90_000,
    maxBuffer: 50 * 1024 * 1024  # 50 MB max output
  });
}

// Available voices:
export const EDGE_TTS_VOICES = [
  { id: "ar-SA-HamedNeural",    name: "🇸🇦 حامد - السعودية",    lang: "ar-SA" },
  { id: "ar-EG-ShakirNeural",   name: "🇪🇬 شاكر - مصر",        lang: "ar-EG" },
  { id: "ar-IQ-BasselNeural",   name: "🇮🇶 باسل - العراق",      lang: "ar-IQ" },
  { id: "ar-MA-JamalNeural",    name: "🇲🇦 جمال - المغرب",      lang: "ar-MA" },
  // ... و10+ أصوات أخرى
];
```

**`processor.ts` (Main Video Processing - 21KB الملف الأساسي)**

هذا الملف يحتوي على العملية الكاملة:

```typescript
export async function processVideoSegment(options: ProcessOptions): Promise<void> {
  // 1. تحميل الفيديو من YouTube
  // 2. استخراج الصوت
  // 3. تشغيل Whisper → استخراج النص
  // 4. ترجمة النص إلى العربية
  // 5. تقسيم النص إلى جمل
  // 6. لكل جملة:
  //    - تحويل نص → صوت (edge-tts)
  //    - حفظ ملف صوتي منفصل
  //    - تحديث Job Status
}

// Helper Functions:

function numberToArabicWords(n: number): string
  // تحويل الأرقام إلى كلمات عربية
  // 123 → "مائة وثلاثة وعشرون"

function prepareTextForTTS(text: string): string
  // تحضير النص قبل TTS:
  // 1. تحويل الأرقام إلى كلمات
  // 2. إزالة الأقواس والعلامات الغريبة
  // 3. تطبيع المسافات

async function downloadAudioSegment(videoUrl, startTime, outputPath, cookiesArgs)
  // تحميل قطعة صوت 60 ثانية من الفيديو باستخدام yt-dlp
  // مع محاولات متعددة للعملاء المختلفة

async function getAudioDuration(audioPath): Promise<number>
  // الحصول على مدة الملف الصوتي باستخدام ffprobe

async function transcribeLocalWhisperJSON(audioPath, modelSize)
  // تشغيل whisper_local.py للحصول على الجمل مع التوقيتات

async function translateWithGoogle/OpenAI/Pollinations(text)
  // ترجمة النص إلى العربية باستخدام خدمات مختلفة

async function applyAtempo(inputPath, rate, outputPath)
  // تعديل سرعة الصوت باستخدام ffmpeg
```

**`whisper_local.py` (Speech-to-Text - Python):**
```python
#!/usr/bin/env python3
"""
Advanced audio transcription pipeline:
Audio Input → VAD → faster-whisper → Post-processing → Output

Usage:
python3 whisper_local.py <audio_file> [model_size]        # plain text
python3 whisper_local.py <audio_file> [model_size] --json  # JSON
"""

FILLER_WORDS = {"uh", "um", "hmm", "hm", "ugh", "ahh", "er", ...}

def post_process(text: str) -> str:
    # تنظيف النص:
    # 1. إزالة كلمات حشو
    # 2. إزالة علامات ترقيم زائدة
    # 3. إزالة نصوص بين أقواس
    # 4. تطبيع المسافات

def transcribe(audio_path, model_size="tiny", return_json=False):
    # تحميل نموذج Whisper
    model = WhisperModel(
        model_size,
        device="cpu",
        compute_type="int8",     # 8-bit for efficiency
        download_root="~/.cache/whisper"
    )

    # محاولة 1: VAD مفعل + threshold عالي (0.28)
    # محاولة 2: VAD + threshold منخفض (0.15)
    # محاولة 3: بدون VAD
    
    # Output:
    # - Plain: "مرحبا بك في العالم"
    # - JSON: [
    #     {
    #       "start": 0.5,
    #       "end": 2.3,
    #       "text": "مرحبا بك",
    #       "words": [
    #         {"word": "مرحبا", "start": 0.5, "end": 1.2},
    #         {"word": "بك", "start": 1.2, "end": 2.3}
    #       ]
    #     }
    #   ]

if __name__ == "__main__":
    # Parse command line arguments
    # Call transcribe()
    # Output result
```

---

## 🔧 أدوات التطوير (scripts/)

### `package.json`
```json
{
  "name": "@workspace/scripts",
  "scripts": {
    "hello": "tsx ./src/hello.ts",
    "typecheck": "tsc -p tsconfig.json --noEmit"
  },
  "devDependencies": {
    "@types/node": "^25.3.3",
    "tsx": "^4.21.0"  # TypeScript Executor
  }
}
```

### `src/hello.ts`
```typescript
console.log("Hello from @workspace/scripts");
```

### `post-merge.sh` (Git Hook)
```bash
#!/bin/bash
set -e
pnpm install --frozen-lockfile    # تثبيت التبعيات
pnpm --filter db push             # تطبيق تغييرات DB
```

**الغرض**: تشغيل تلقائي بعد دمج الفروع

---

## 🔄 سير العمل الكامل

### مثال: ترجمة فيديو YouTube

```
1️⃣ المستخدم يُرسل طلب:
   POST /api/translate/process
   {
     "videoUrl": "https://youtube.com/watch?v=...",
     "voice": "ar-SA-HamedNeural",
     "translationEngine": "openai",
     "startTime": 30  # Start from 30 seconds
   }

2️⃣ الخادم ينشئ Job:
   {
     "jobId": "550e8400-e29b-41d4-a716-446655440000",
     "status": "pending",
     "message": "بدأت المعالجة"
   }

3️⃣ في الخلفية (لا ننتظر):
   a. تحميل الفيديو من YouTube
      ↓ (استخدام yt-dlp مع كوكيز إن وجدت)
   
   b. استخراج الصوت (60 ثانية)
      ↓
   
   c. تشغيل whisper_local.py
      ↓
      Output: [
        {"start": 0, "end": 2, "text": "مرحبا", "words": [...]},
        {"start": 2, "end": 5, "text": "بك", "words": [...]},
        ...
      ]
   
   d. لكل جملة بالتوازي (Promise.all):
      ✓ ترجمة النص
      ✓ تحويل النص → صوت (edge-tts)
      ✓ حفظ ملف MP3 منفصل
      ✓ تحديث Job Status
   
   e. عندما تنتهي جميع الجمل:
      - status = "completed"
      - المستخدم يمكنه تحميل الملفات

4️⃣ المستخدم يسأل عن الحالة:
   GET /api/translate/status/{jobId}
   
   Response:
   {
     "jobId": "550e8400-...",
     "status": "completed",
     "progress": "✅ 5/5 جملة جاهزة للتشغيل",
     "transcript": "مرحبا بك في العالم",
     "sentences": [
       {
         "videoStart": 0,
         "videoEnd": 2,
         "arabicText": "مرحبا",
         "audioUrl": "/api/translate/sentence-audio/{jobId}/0",
         "audioDuration": 1.5,
         "sentenceStatus": "completed"
       },
       ...
     ]
   }

5️⃣ تحميل ملفات الصوت:
   GET /api/translate/sentence-audio/{jobId}/{idx}
   
   Response: audio/mpeg file (MP3)
```

---

## 🚀 الأوامر والتشغيل

### تثبيت المشروع
```bash
# تثبيت pnpm عالمياً
npm install -g pnpm

# تثبيت التبعيات
pnpm install

# تثبيت Python
python -m pip install edge-tts faster-whisper
```

### التطوير
```bash
# فحص الأنواع
pnpm run typecheck

# البناء الكامل
pnpm run build

# تشغيل الخادم في وضع التطوير
pnpm --filter @workspace/api-server run dev

# تطبيق تغييرات قاعدة البيانات
pnpm --filter @workspace/db run push

# توليد الأكواد من OpenAPI
pnpm --filter @workspace/api-spec run codegen

# اختبار السكريبتات
pnpm --filter @workspace/scripts run hello
```

### متغيرات البيئة
```bash
# .env (في الجذر)

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/empty-space

# API
PORT=3000
NODE_ENV=development
LOG_LEVEL=info

# AI Services
AI_INTEGRATIONS_OPENAI_API_KEY=sk-...
AI_INTEGRATIONS_OPENAI_BASE_URL=https://api.openai.com/v1
```

---

## 📊 ملخص المكونات

| المكون | الوصف | الملفات |
|-------|-------|---------|
| **Root** | تكوين Monorepo | package.json, pnpm-workspace.yaml |
| **lib/db** | قاعدة البيانات | drizzle.config.ts, schema/* |
| **lib/api-spec** | مواصفات API | openapi.yaml, orval.config.ts |
| **lib/api-zod** | Validation | generated/api.ts |
| **lib/api-client-react** | React Hooks | (قيد التطوير) |
| **artifacts/api-server** | الخادم الرئيسي | app.ts, routes/* |
| **routes/translate** | منطق الترجمة | processor.ts, jobs.ts |
| **whisper_local.py** | ASR (Python) | استخراج النص من الصوت |
| **scripts** | أدوات التطوير | post-merge.sh |

---

## ✨ الميزات الرئيسية

✅ Monorepo Structure  
✅ TypeScript + Strict Mode  
✅ OpenAPI + Orval Code Generation  
✅ Zod Validation  
✅ PostgreSQL + Drizzle ORM  
✅ Express 5 API  
✅ YouTube Video Download (yt-dlp)  
✅ Speech-to-Text (faster-whisper)  
✅ Text Translation (OpenAI/Google/Pollinations)  
✅ Text-to-Speech (edge-tts)  
✅ Parallel Sentence Processing  
✅ Per-Sentence Audio Files  
✅ Job Management  
✅ Cookie Management (YouTube Authentication)  
✅ Multiple Arabic Voices  
✅ Environment Variables + Security  
✅ Production-Ready Build (esbuild ESM)  
✅ Supply Chain Security (1-day minimum age)

---

## 🎯 الخلاصة

هذا المشروع هو **نظام متكامل** لترجمة فيديوهات YouTube تلقائياً:

1. **Architecture**: Monorepo مع Workspace
2. **Backend**: Express 5 + PostgreSQL
3. **Processing**: Whisper + Translation APIs + edge-tts
4. **API**: OpenAPI 3.1 + Code Generation
5. **Validation**: Zod Schemas
6. **Deployment**: Replit + esbuild ESM
7. **Security**: Cookie Management + Supply Chain Defense

كل مكون لديه مسؤولية واحدة وواضحة، مع فصل نظيف بين الطبقات! 🚀
